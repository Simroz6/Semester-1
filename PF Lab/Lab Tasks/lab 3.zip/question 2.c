#include <stdio.h>
int main(){

int x,y;
printf("Enter 2 integer values: ");
scanf("%d %d",&x,&y);
printf("Values are:%d %d ",y,x);
}

#include <stdio.h>
int main(){
	
	float tr,sal;
	printf("Enter tax rate and salary ");
	scanf("%f%f",&tr,&sal);
	float tax = (tr/100)*sal;
	float fsal=sal-tax;
	printf("Tax on salary is: %f",tax);
	printf("Final salary afer tax is: %f", fsal);
}

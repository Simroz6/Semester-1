#include <stdio.h>
int main ()
{
    float rate,tp,prin,inte;
    printf("Enter principal(amount should be between Rs.100-1,000,000),rate of interest(percent should be between 5 - 10 ) and time period (should be between 1 to 10 years)");
    scanf("%f%f%f",&prin,&rate,&tp);
    inte = prin*tp*rate/100;
    printf("Simple interest is: %f",inte);
}
#include <stdio.h>
int main ()
{
    float km,miles;
    printf("Enter kilometers: ");
    scanf("%f",&km);
    miles = km*0.62;
    printf("Miles is: %f",miles);
}
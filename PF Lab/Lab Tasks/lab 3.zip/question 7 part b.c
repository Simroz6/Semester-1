#include <stdio.h>
int main ()
{
   float fer,temp;
   printf("Enter temperature in farenhite: ");
   scanf("%f", &fer);
   temp = (32*fer - 32)*5/9; //celcius to farenhite
   printf("Temperature in celcius is: %f",temp);
}





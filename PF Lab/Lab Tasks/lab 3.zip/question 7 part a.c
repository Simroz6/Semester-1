#include <stdio.h>
int main ()
{
   float cel,temp;
   printf("Enter temperature in celcius: ");
   scanf("%f", &cel);
   temp = (cel*9/5)+32; //celcius to farenhite
   printf("Temperature in farenhite is: %f",temp);
}





#include <stdio.h>

int main() {
    long long int testInteger = 3000000000;
    printf("Number is: %lld", testInteger);
}
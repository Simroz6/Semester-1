#include <stdio.h>
int main ()
{
   float weg,het,bmi;
   printf("Enter weight in kg and height in meters: ");
   scanf("%f%f",&weg,&het);
   bmi = weg/(het*het);
   printf("BMI is: %f",bmi);
}
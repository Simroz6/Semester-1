#include <stdio.h>
int main ()
{
   float len,wid,area;
   printf("Enter length and width of rectangle: ");
   scanf("%f%f",&len,&wid);
   area = len*wid;
   printf("Area of rectangle is: %f",area);
}
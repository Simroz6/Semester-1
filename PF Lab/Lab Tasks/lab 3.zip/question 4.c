#include <stdio.h>
int main(){

float avgfuel;
printf("Enter average fuel in liters for whole trip (only positive value): ");
scanf("%f",&avgfuel);
float tfuel = avgfuel*2;
float cfuel = (avgfuel*118) + (avgfuel*123);
printf("Total fue consumed is: %f\n",tfuel);
printf("Total cost of fuel is: %f",cfuel);
}



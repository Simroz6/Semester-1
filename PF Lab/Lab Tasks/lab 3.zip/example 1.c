#include<stdio.h>
int main(){
//printing character data
char ch='A';
printf("Printing character data: %c\n", ch);
//print decimal or integer date with d and i
int x = 45, y=90;
printf("Printing decimal data: %d\n", x);
printf("Printing Integer data: %i\n", y);
//print float value
float f = 12.67;
printf("Printing floating point data: %f\n", f);
//print in scientific notation
printf("Print in scientific notation: Se\n", f);
//print in octal format
int a = 67;
printf("Printing data in octal format: No\n", a);
//print in hex format
printf("Printing data in hex format: %x\n", a);
float z = 3.8;
printf("Float value of y is: %g\n", z);
printf("Address value of y in hexadecimal form is: %p\n", &y);
char str[] ="Hello World";
printf("%s\n", str);
printf("shift to the right 20 characters: %20s\n", str); 

int testinteger=5;
printf("Number is %d", testinteger);
}
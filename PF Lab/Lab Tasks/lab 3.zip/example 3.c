#include <stdio.h>
int main(){
	
	char ch1 = '\t';
	char ch2 = '\n';
	printf("Test for tabspace %c and newline %c will start here, now testing beep \a and question marks \?",ch1,ch2);
	
	double a = 2.55555588889999;
	printf("Before setting the precision\number is %lf", a);
	printf("After setting the prrecision\number is %.14lf",a);
	
	
	
	
	
	
}
